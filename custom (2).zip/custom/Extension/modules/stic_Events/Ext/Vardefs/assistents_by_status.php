<?php
$dictionary['stic_Events']['fields']['stic_cs_h_majors_c'] = [
    'name' => 'stic_cs_h_majors_c',
    'vname' => 'LBL_STIC_CS_H_MAJORS',
    'type' => 'int',
    'dbType' => 'int',
    'len' => '11',
    'validation' => [
        'type' => 'range',
        'min' => 0,
    ],
    'audited' => false,
    'importable' => 'true',
];
$dictionary['stic_Events']['fields']['stic_cs_d_majors_c'] = [
    'name' => 'stic_cs_d_majors_c',
    'vname' => 'LBL_STIC_CS_D_MAJORS',
    'type' => 'int',
    'dbType' => 'int',
    'len' => '11',
    'validation' => [
        'type' => 'range',
        'min' => 0,
    ],
    'audited' => false,
    'importable' => 'true',
];
$dictionary['stic_Events']['fields']['stic_cs_h_minors_c'] = [
    'name' => 'stic_cs_h_minors_c',
    'vname' => 'LBL_STIC_CS_H_MINORS',
    'type' => 'int',
    'dbType' => 'int',
    'len' => '11',
    'validation' => [
        'type' => 'range',
        'min' => 0,
    ],
    'audited' => false,
    'importable' => 'true',
];
$dictionary['stic_Events']['fields']['stic_cs_d_minors_c'] = [
    'name' => 'stic_cs_d_minors_c',
    'vname' => 'LBL_STIC_CS_D_MINORS',
    'type' => 'int',
    'dbType' => 'int',
    'len' => '11',
    'validation' => [
        'type' => 'range',
        'min' => 0,
    ],
    'audited' => false,
    'importable' => 'true',
];
$dictionary['stic_Events']['fields']['stic_cs_inherit_reg_c'] = [
    'name' => 'stic_cs_inherit_reg_c',
    'vname' => 'LBL_STIC_CS_INHERIT_REG',
    'type' => 'bool',
    'len' => '11',
    'audited' => false,
    'importable' => 'true',
];